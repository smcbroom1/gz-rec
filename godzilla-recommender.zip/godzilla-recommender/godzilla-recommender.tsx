"use client"

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { godzillaMovies, GodzillaMovie } from './data/godzillaMovies'

const questions = [
  {
    id: 'effects',
    question: 'How important are special effects to you?',
    options: [
      { value: '1', label: 'Not important' },
      { value: '3', label: 'Somewhat important' },
      { value: '5', label: 'Very important' },
    ],
  },
  {
    id: 'story',
    question: 'Do you prefer a strong storyline?',
    options: [
      { value: '1', label: 'Not really' },
      { value: '3', label: 'It\'s nice to have' },
      { value: '5', label: 'Absolutely' },
    ],
  },
  {
    id: 'action',
    question: 'How much monster action do you want?',
    options: [
      { value: '1', label: 'Minimal' },
      { value: '3', label: 'A good balance' },
      { value: '5', label: 'Lots of action' },
    ],
  },
  {
    id: 'tone',
    question: 'What tone do you prefer?',
    options: [
      { value: 'serious', label: 'Serious and dark' },
      { value: 'balanced', label: 'A mix of serious and light-hearted' },
      { value: 'light', label: 'More light-hearted and fun' },
    ],
  },
  {
    id: 'monsters',
    question: 'Do you want to see multiple monsters?',
    options: [
      { value: 'no', label: 'No, focus on Godzilla' },
      { value: 'yes', label: 'Yes, the more the merrier' },
    ],
  },
]

export default function GodzillaRecommender() {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState<Record<string, string>>({})
  const [recommendation, setRecommendation] = useState<GodzillaMovie | null>(null)
  const [currentAnswer, setCurrentAnswer] = useState<string>("")
  const [direction, setDirection] = useState(0)

  const handleAnswer = (value: string) => {
    setCurrentAnswer(value)
  }

  const handleNext = () => {
    if (currentAnswer) {
      setAnswers({ ...answers, [questions[currentQuestion].id]: currentAnswer })
      if (currentQuestion < questions.length - 1) {
        setDirection(1)
        setCurrentQuestion(currentQuestion + 1)
        setCurrentAnswer("") // Reset the current answer
      } else {
        getRecommendation()
      }
    }
  }

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setDirection(-1)
      setCurrentQuestion(currentQuestion - 1)
      setCurrentAnswer(answers[questions[currentQuestion - 1].id] || "")
    }
  }

  const getRecommendation = () => {
    let bestMatch: GodzillaMovie | null = null
    let highestScore = -Infinity

    godzillaMovies.forEach(movie => {
      let score = 0
      score += Math.abs(movie.features.specialEffects - parseInt(answers.effects)) * -1
      score += Math.abs(movie.features.story - parseInt(answers.story)) * -1
      score += Math.abs(movie.features.action - parseInt(answers.action)) * -1
      
      if (answers.tone === 'serious' && movie.features.seriousness > 3) score += 2
      if (answers.tone === 'light' && movie.features.humor > 3) score += 2
      if (answers.tone === 'balanced' && movie.features.seriousness === 3) score += 2

      if (answers.monsters === 'yes' && movie.features.multipleMonsters) score += 2
      if (answers.monsters === 'no' && !movie.features.multipleMonsters) score += 2

      if (score > highestScore) {
        highestScore = score
        bestMatch = movie
      }
    })

    setRecommendation(bestMatch)
  }

  const resetQuiz = () => {
    setCurrentQuestion(0)
    setAnswers({})
    setRecommendation(null)
    setCurrentAnswer("")
    setDirection(0)
  }

  const variants = {
    enter: (direction: number) => {
      return {
        x: direction > 0 ? 1000 : -1000,
        opacity: 0
      };
    },
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1
    },
    exit: (direction: number) => {
      return {
        zIndex: 0,
        x: direction < 0 ? 1000 : -1000,
        opacity: 0
      };
    }
  };

  return (
    <Card className="w-full max-w-lg mx-auto">
      <CardHeader>
        <CardTitle>Godzilla Movie Recommender</CardTitle>
        <CardDescription>Answer a few questions to get your perfect Godzilla movie recommendation!</CardDescription>
      </CardHeader>
      <CardContent>
        <AnimatePresence mode="wait" custom={direction}>
          {!recommendation ? (
            <motion.div
              key={currentQuestion}
              custom={direction}
              variants={variants}
              initial="enter"
              animate="center"
              exit="exit"
              transition={{
                x: { type: "spring", stiffness: 300, damping: 30 },
                opacity: { duration: 0.2 }
              }}
            >
              <h3 className="text-lg font-semibold mb-4">{questions[currentQuestion].question}</h3>
              <RadioGroup value={currentAnswer} onValueChange={handleAnswer}>
                {questions[currentQuestion].options.map((option) => (
                  <div key={option.value} className="flex items-center space-x-2">
                    <RadioGroupItem value={option.value} id={option.value} />
                    <Label htmlFor={option.value}>{option.label}</Label>
                  </div>
                ))}
              </RadioGroup>
              <div className="flex justify-between mt-4">
                <Button onClick={handlePrevious} disabled={currentQuestion === 0}>
                  Previous
                </Button>
                <Button onClick={handleNext} disabled={!currentAnswer}>
                  {currentQuestion === questions.length - 1 ? "Get Recommendation" : "Next"}
                </Button>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="recommendation"
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -50 }}
              transition={{ duration: 0.5 }}
            >
              <h3 className="text-lg font-semibold mb-4">Your Recommended Godzilla Movie:</h3>
              <p className="text-2xl font-bold mb-2">{recommendation.title}</p>
              <p>Year: {recommendation.year}</p>
              <p>Era: {recommendation.era}</p>
            </motion.div>
          )}
        </AnimatePresence>
      </CardContent>
      <CardFooter>
        {recommendation && (
          <Button onClick={resetQuiz}>Start Over</Button>
        )}
      </CardFooter>
    </Card>
  )
}

