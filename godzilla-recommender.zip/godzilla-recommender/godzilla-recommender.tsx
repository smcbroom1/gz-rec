import { useState } from 'react'
import { Card, CardContent, Button, RadioGroup, RadioGroupItem, Label } from '@nextui-org/react'

const godzillaMovies = [
  { title: "Godzilla (1954)", year: 1954, era: "Showa", score: 0.8, tags: ["classic", "monster battle", "destruction"] },
  { title: "Godzilla vs. Mechagodzilla (1974)", year: 1974, era: "Showa", score: 0.7, tags: ["monster battle", "sci-fi", "destruction"] },
  { title: "Godzilla (2014)", year: 2014, era: "Legendary", score: 0.9, tags: ["monster battle", "destruction", "sci-fi"] },
  { title: "Godzilla vs. Kong (2021)", year: 2021, era: "MonsterVerse", score: 0.6, tags: ["monster battle", "sci-fi", "action"] },
  { title: "Shin Godzilla (2016)", year: 2016, era: "Reiwa", score: 0.85, tags: ["destruction", "horror", "allegory"] },
  { title: "Godzilla, King of the Monsters (2019)", year: 2019, era: "MonsterVerse", score: 0.75, tags: ["monster battle", "sci-fi", "action", "comedy"] },

]

const getRecommendations = (movies, preferences) => {
  return movies
    .map(movie => ({
      ...movie,
      score: calculateScore(movie, preferences)
    }))
    .sort((a, b) => b.score - a.score)
    .filter(movie => movie.score > 0)
}

const calculateScore = (movie, preferences) => {
  let score = 0;
  score += Math.abs(movie.year - 2023) / 100 //Recency bias
  score += preferences.effects * 0.2;
  score += preferences.story * 0.2;
  score += preferences.action * 0.2;
  score += preferences.tone === movie.era ? 0.2 : 0;
  score += movie.tags.filter(tag => preferences.preferredTags.includes(tag)).length * 0.1;
  return score;
}


const questions = [
  {
    id: 'effects',
    question: 'How important are special effects to you?',
    options: [
      { value: '1', label: 'Not Important' },
      { value: '2', label: 'Somewhat Important' },
      { value: '3', label: 'Important' },
      { value: '4', label: 'Very Important' },
    ],
  },
  {
    id: 'story',
    question: 'How important is the story to you?',
    options: [
      { value: '1', label: 'Not Important' },
      { value: '2', label: 'Somewhat Important' },
      { value: '3', label: 'Important' },
      { value: '4', label: 'Very Important' },
    ],
  },
  {
    id: 'action',
    question: 'How important is the action to you?',
    options: [
      { value: '1', label: 'Not Important' },
      { value: '2', label: 'Somewhat Important' },
      { value: '3', label: 'Important' },
      { value: '4', label: 'Very Important' },
    ],
  },
  {
    id: 'tone',
    question: 'What kind of tone are you looking for?',
    options: [
      { value: 'serious', label: 'Serious' },
      { value: 'balanced', label: 'Balanced' },
      { value: 'light', label: 'Lighthearted' },
    ],
  },
  {
    id: 'monsterTypes',
    question: 'What kind of monsters are you interested in?',
    options: [
      { value: 'Godzilla', label: 'Godzilla' },
      { value: 'Mechagodzilla', label: 'Mechagodzilla' },
      { value: 'King Ghidorah', label: 'King Ghidorah' },
      { value: 'Mothra', label: 'Mothra' },
    ],
    multiple: true,
  },
  {
    id: 'preferredTags',
    question: 'Select your preferred themes or elements:',
    options: [
      { value: 'classic', label: 'Classic' },
      { value: 'monster battle', label: 'Monster Battles' },
      { value: 'sci-fi', label: 'Science Fiction' },
      { value: 'destruction', label: 'City Destruction' },
      { value: 'horror', label: 'Horror Elements' },
      { value: 'comedy', label: 'Comedic Moments' },
      { value: 'allegory', label: 'Social Commentary' },
    ],
    multiple: true,
  },
]

export default function GodzillaRecommender() {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [currentAnswer, setCurrentAnswer] = useState('')
  const [answers, setAnswers] = useState({})
  const [recommendations, setRecommendations] = useState([])
  const [currentRecommendationIndex, setCurrentRecommendationIndex] = useState(0)
  const [alreadySeenCount, setAlreadySeenCount] = useState(0)
  const [selectedTags, setSelectedTags] = useState<string[]>([])

  const handleAnswer = (value: string) => {
    if (questions[currentQuestion].multiple) {
      setSelectedTags(prev => 
        prev.includes(value) ? prev.filter(tag => tag !== value) : [...prev, value]
      )
    } else {
      setCurrentAnswer(value)
    }
  }

  const handleNext = () => {
    if (currentAnswer || (questions[currentQuestion].multiple && selectedTags.length > 0)) {
      if (questions[currentQuestion].multiple) {
        setAnswers({ ...answers, [questions[currentQuestion].id]: selectedTags })
      } else {
        setAnswers({ ...answers, [questions[currentQuestion].id]: currentAnswer })
      }
      if (currentQuestion < questions.length - 1) {
        setCurrentQuestion(currentQuestion + 1)
        setCurrentAnswer("")
        setSelectedTags([])
      } else {
        generateRecommendations()
      }
    }
  }

  const generateRecommendations = () => {
    const userPreferences = {
      effects: parseInt(answers.effects),
      story: parseInt(answers.story),
      action: parseInt(answers.action),
      tone: answers.tone as 'serious' | 'balanced' | 'light',
      monsterTypes: answers.monsterTypes,
      preferredTags: answers.preferredTags as string[],
    }
    const recommendedMovies = getRecommendations(godzillaMovies, userPreferences)
    setRecommendations(recommendedMovies)
    setCurrentRecommendationIndex(0)
  }

  const handleAlreadySeen = () => {
    setAlreadySeenCount(alreadySeenCount + 1)
    setCurrentRecommendationIndex(currentRecommendationIndex + 1)
  }

  const currentRecommendation = recommendations[currentRecommendationIndex]

  return (
    <Card className="w-full max-w-lg mx-auto">
      <CardContent>
        {recommendations.length === 0 ? (
          <div>
            <h3 className="text-lg font-semibold mb-4">{questions[currentQuestion].question}</h3>
            {questions[currentQuestion].multiple ? (
              <div className="space-y-2">
                {questions[currentQuestion].options.map((option) => (
                  <div key={option.value} className="flex items-center">
                    <input
                      type="checkbox"
                      id={option.value}
                      value={option.value}
                      checked={selectedTags.includes(option.value)}
                      onChange={() => handleAnswer(option.value)}
                      className="mr-2"
                    />
                    <Label htmlFor={option.value}>{option.label}</Label>
                  </div>
                ))}
              </div>
            ) : (
              <RadioGroup value={currentAnswer} onValueChange={handleAnswer}>
                {questions[currentQuestion].options.map((option) => (
                  <div key={option.value} className="flex items-center space-x-2">
                    <RadioGroupItem value={option.value} id={option.value} />
                    <Label htmlFor={option.value}>{option.label}</Label>
                  </div>
                ))}
              </RadioGroup>
            )}
            <Button 
              onClick={handleNext} 
              className="mt-4" 
              disabled={!currentAnswer && (!questions[currentQuestion].multiple || selectedTags.length === 0)}
            >
              {currentQuestion === questions.length - 1 ? "Get Recommendation" : "Next"}
            </Button>
          </div>
        ) : (
          <div>
            <h3 className="text-lg font-semibold mb-4">Your Recommended Godzilla Movie:</h3>
            <p className="text-2xl font-bold mb-2">{currentRecommendation.title}</p>
            <div className="w-full">
              <p>Year: {currentRecommendation.year}</p>
              <p>Era: {currentRecommendation.era}</p>
              <p>Match Score: {(currentRecommendation.score * 100).toFixed(2)}%</p>
              <p>Tags: {currentRecommendation.tags.join(', ')}</p>
            </div>
            <div className="mt-4 space-x-2">
              <Button 
                onClick={handleAlreadySeen} 
                disabled={currentRecommendationIndex === recommendations.length - 1 || alreadySeenCount >= 4}
              >
                I've already seen this one ({4 - alreadySeenCount} skips left)
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

