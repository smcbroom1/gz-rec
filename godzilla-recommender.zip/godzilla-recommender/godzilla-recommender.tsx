"use client"

import { useState, useRef } from 'react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { godzillaMovies, GodzillaMovie } from './data/godzillaMovies'

const questions = [
  {
    id: 'effects',
    question: 'How important are special effects to you?',
    options: [
      { value: '1', label: 'Not important' },
      { value: '3', label: 'Somewhat important' },
      { value: '5', label: 'Very important' },
    ],
  },
  {
    id: 'story',
    question: 'Do you prefer a strong storyline?',
    options: [
      { value: '1', label: 'Not really' },
      { value: '3', label: 'It\'s nice to have' },
      { value: '5', label: 'Absolutely' },
    ],
  },
  {
    id: 'action',
    question: 'How much monster action do you want?',
    options: [
      { value: '1', label: 'Minimal' },
      { value: '3', label: 'A good balance' },
      { value: '5', label: 'Lots of action' },
    ],
  },
  {
    id: 'tone',
    question: 'What tone do you prefer?',
    options: [
      { value: 'serious', label: 'Serious and dark' },
      { value: 'balanced', label: 'A mix of serious and light-hearted' },
      { value: 'light', label: 'More light-hearted and fun' },
    ],
  },
  {
    id: 'monsters',
    question: 'Do you want to see multiple monsters?',
    options: [
      { value: 'no', label: 'No, focus on Godzilla' },
      { value: 'yes', label: 'Yes, the more the merrier' },
    ],
  },
]

export default function GodzillaRecommender() {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState<Record<string, string>>({})
  const [recommendation, setRecommendation] = useState<GodzillaMovie | null>(null)
  const formRef = useRef<HTMLFormElement>(null)

  const handleAnswer = (value: string) => {
    setAnswers({ ...answers, [questions[currentQuestion].id]: value })
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
      // Reset the form after setting the next question
      if (formRef.current) {
        formRef.current.reset()
      }
    } else {
      getRecommendation()
    }
  }

  const getRecommendation = () => {
    let bestMatch: GodzillaMovie | null = null
    let highestScore = -Infinity

    godzillaMovies.forEach(movie => {
      let score = 0
      score += Math.abs(movie.features.specialEffects - parseInt(answers.effects)) * -1
      score += Math.abs(movie.features.story - parseInt(answers.story)) * -1
      score += Math.abs(movie.features.action - parseInt(answers.action)) * -1
      
      if (answers.tone === 'serious' && movie.features.seriousness > 3) score += 2
      if (answers.tone === 'light' && movie.features.humor > 3) score += 2
      if (answers.tone === 'balanced' && movie.features.seriousness === 3) score += 2

      if (answers.monsters === 'yes' && movie.features.multipleMonsters) score += 2
      if (answers.monsters === 'no' && !movie.features.multipleMonsters) score += 2

      if (score > highestScore) {
        highestScore = score
        bestMatch = movie
      }
    })

    setRecommendation(bestMatch)
  }

  const resetQuiz = () => {
    setCurrentQuestion(0)
    setAnswers({})
    setRecommendation(null)
  }

  return (
    <Card className="w-full max-w-lg mx-auto">
      <CardHeader>
        <CardTitle>Godzilla Movie Recommender</CardTitle>
        <CardDescription>Answer a few questions to get your perfect Godzilla movie recommendation!</CardDescription>
      </CardHeader>
      <CardContent>
        {!recommendation ? (
          <div>
            <h3 className="text-lg font-semibold mb-4">{questions[currentQuestion].question}</h3>
            <form ref={formRef}>
              <RadioGroup onValueChange={handleAnswer}>
                {questions[currentQuestion].options.map((option) => (
                  <div key={option.value} className="flex items-center space-x-2">
                    <RadioGroupItem value={option.value} id={option.value} />
                    <Label htmlFor={option.value}>{option.label}</Label>
                  </div>
                ))}
              </RadioGroup>
            </form>
          </div>
        ) : (
          <div>
            <h3 className="text-lg font-semibold mb-4">Your Recommended Godzilla Movie:</h3>
            <p className="text-2xl font-bold mb-2">{recommendation.title}</p>
            <p>Year: {recommendation.year}</p>
            <p>Era: {recommendation.era}</p>
          </div>
        )}
      </CardContent>
      <CardFooter>
        {recommendation && (
          <Button onClick={resetQuiz}>Start Over</Button>
        )}
      </CardFooter>
    </Card>
  )
}

