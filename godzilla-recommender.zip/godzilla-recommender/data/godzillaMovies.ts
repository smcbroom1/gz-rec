export interface GodzillaMovie {
  title: string;
  year: number;
  era: 'Showa' | 'Heisei' | 'Millennium' | 'MonsterVerse' | 'Reiwa';
  features: {
    specialEffects: number; // 1-5 scale
    story: number; // 1-5 scale
    action: number; // 1-5 scale
    humor: number; // 1-5 scale
    seriousness: number; // 1-5 scale
    multipleMonsters: boolean;
  };
}

export const godzillaMovies: GodzillaMovie[] = [
  {
    title: "Godzilla (1954)",
    year: 1954,
    era: "Showa",
    features: {
      specialEffects: 4,
      story: 5,
      action: 3,
      humor: 1,
      seriousness: 5,
      multipleMonsters: false
    }
  },
  {
    title: "Godzilla vs. King Ghidorah",
    year: 1991,
    era: "Heisei",
    features: {
      specialEffects: 4,
      story: 4,
      action: 5,
      humor: 2,
      seriousness: 4,
      multipleMonsters: true
    }
  },
  {
    title: "Godzilla, Mothra and King Ghidorah: Giant Monsters All-Out Attack",
    year: 2001,
    era: "Millennium",
    features: {
      specialEffects: 5,
      story: 4,
      action: 5,
      humor: 2,
      seriousness: 4,
      multipleMonsters: true
    }
  },
  {
    title: "Godzilla (2014)",
    year: 2014,
    era: "MonsterVerse",
    features: {
      specialEffects: 5,
      story: 3,
      action: 4,
      humor: 2,
      seriousness: 5,
      multipleMonsters: true
    }
  },
  {
    title: "Shin Godzilla",
    year: 2016,
    era: "Reiwa",
    features: {
      specialEffects: 5,
      story: 5,
      action: 4,
      humor: 3,
      seriousness: 5,
      multipleMonsters: false
    }
  }
];

