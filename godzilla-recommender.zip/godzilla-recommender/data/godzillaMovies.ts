export interface GodzillaMovie {
  title: string;
  year: number;
  era: 'Showa' | 'Heisei' | 'Millennium' | 'MonsterVerse' | 'Reiwa';
  features: {
    specialEffects: number; // 1-5 scale
    story: number; // 1-5 scale
    action: number; // 1-5 scale
    humor: number; // 1-5 scale
    seriousness: number; // 1-5 scale
    multipleMonsters: boolean;
  };
}

export const godzillaMovies: GodzillaMovie[] = [
  {
    title: "Godzilla (1954)",
    year: 1954,
    era: "Showa",
    features: {
      specialEffects: 4,
      story: 5,
      action: 3,
      humor: 1,
      seriousness: 5,
      multipleMonsters: false
    }
  },
  {
    title: "Godzilla Raids Again",
    year: 1955,
    era: "Showa",
    features: {
      specialEffects: 3,
      story: 3,
      action: 4,
      humor: 2,
      seriousness: 4,
      multipleMonsters: true
    }
  },
  {
    title: "King Kong vs. Godzilla",
    year: 1962,
    era: "Showa",
    features: {
      specialEffects: 3,
      story: 3,
      action: 5,
      humor: 4,
      seriousness: 2,
      multipleMonsters: true
    }
  },
  {
    title: "Mothra vs. Godzilla",
    year: 1964,
    era: "Showa",
    features: {
      specialEffects: 4,
      story: 4,
      action: 4,
      humor: 2,
      seriousness: 3,
      multipleMonsters: true
    }
  },
  {
    title: "Ghidorah, the Three-Headed Monster",
    year: 1964,
    era: "Showa",
    features: {
      specialEffects: 4,
      story: 4,
      action: 5,
      humor: 3,
      seriousness: 3,
      multipleMonsters: true
    }
  },
  {
    title: "Invasion of Astro-Monster",
    year: 1965,
    era: "Showa",
    features: {
      specialEffects: 4,
      story: 4,
      action: 4,
      humor: 3,
      seriousness: 3,
      multipleMonsters: true
    }
  },
  {
    title: "Ebirah, Horror of the Deep",
    year: 1966,
    era: "Showa",
    features: {
      specialEffects: 3,
      story: 3,
      action: 4,
      humor: 4,
      seriousness: 2,
      multipleMonsters: true
    }
  },
  {
    title: "Son of Godzilla",
    year: 1967,
    era: "Showa",
    features: {
      specialEffects: 3,
      story: 3,
      action: 3,
      humor: 4,
      seriousness: 2,
      multipleMonsters: true
    }
  },
  {
    title: "Destroy All Monsters",
    year: 1968,
    era: "Showa",
    features: {
      specialEffects: 4,
      story: 4,
      action: 5,
      humor: 3,
      seriousness: 3,
      multipleMonsters: true
    }
  },
  {
    title: "All Monsters Attack",
    year: 1969,
    era: "Showa",
    features: {
      specialEffects: 2,
      story: 2,
      action: 3,
      humor: 4,
      seriousness: 1,
      multipleMonsters: true
    }
  },
  {
    title: "Godzilla vs. Hedorah",
    year: 1971,
    era: "Showa",
    features: {
      specialEffects: 3,
      story: 4,
      action: 4,
      humor: 3,
      seriousness: 3,
      multipleMonsters: true
    }
  },
  {
    title: "Godzilla vs. Gigan",
    year: 1972,
    era: "Showa",
    features: {
      specialEffects: 3,
      story: 3,
      action: 4,
      humor: 3,
      seriousness: 2,
      multipleMonsters: true
    }
  },
  {
    title: "Godzilla vs. Megalon",
    year: 1973,
    era: "Showa",
    features: {
      specialEffects: 2,
      story: 2,
      action: 4,
      humor: 4,
      seriousness: 1,
      multipleMonsters: true
    }
  },
  {
    title: "Godzilla vs. Mechagodzilla",
    year: 1974,
    era: "Showa",
    features: {
      specialEffects: 4,
      story: 4,
      action: 5,
      humor: 3,
      seriousness: 3,
      multipleMonsters: true
    }
  },
  {
    title: "Terror of Mechagodzilla",
    year: 1975,
    era: "Showa",
    features: {
      specialEffects: 4,
      story: 4,
      action: 4,
      humor: 2,
      seriousness: 4,
      multipleMonsters: true
    }
  },
  {
    title: "The Return of Godzilla",
    year: 1984,
    era: "Heisei",
    features: {
      specialEffects: 4,
      story: 4,
      action: 4,
      humor: 1,
      seriousness: 5,
      multipleMonsters: false
    }
  },
  {
    title: "Godzilla vs. Biollante",
    year: 1989,
    era: "Heisei",
    features: {
      specialEffects: 5,
      story: 4,
      action: 4,
      humor: 2,
      seriousness: 4,
      multipleMonsters: true
    }
  },
  {
    title: "Godzilla vs. King Ghidorah",
    year: 1991,
    era: "Heisei",
    features: {
      specialEffects: 4,
      story: 4,
      action: 5,
      humor: 2,
      seriousness: 4,
      multipleMonsters: true
    }
  },
  {
    title: "Godzilla vs. Mothra",
    year: 1992,
    era: "Heisei",
    features: {
      specialEffects: 4,
      story: 3,
      action: 4,
      humor: 2,
      seriousness: 4,
      multipleMonsters: true
    }
  },
  {
    title: "Godzilla vs. Mechagodzilla II",
    year: 1993,
    era: "Heisei",
    features: {
      specialEffects: 5,
      story: 4,
      action: 5,
      humor: 2,
      seriousness: 4,
      multipleMonsters: true
    }
  },
  {
    title: "Godzilla vs. SpaceGodzilla",
    year: 1994,
    era: "Heisei",
    features: {
      specialEffects: 4,
      story: 3,
      action: 4,
      humor: 2,
      seriousness: 3,
      multipleMonsters: true
    }
  },
  {
    title: "Godzilla vs. Destoroyah",
    year: 1995,
    era: "Heisei",
    features: {
      specialEffects: 5,
      story: 5,
      action: 5,
      humor: 1,
      seriousness: 5,
      multipleMonsters: true
    }
  },
  {
    title: "Godzilla 2000: Millennium",
    year: 1999,
    era: "Millennium",
    features: {
      specialEffects: 4,
      story: 3,
      action: 4,
      humor: 2,
      seriousness: 4,
      multipleMonsters: true
    }
  },
  {
    title: "Godzilla vs. Megaguirus",
    year: 2000,
    era: "Millennium",
    features: {
      specialEffects: 4,
      story: 3,
      action: 4,
      humor: 2,
      seriousness: 3,
      multipleMonsters: true
    }
  },
  {
    title: "Godzilla, Mothra and King Ghidorah: Giant Monsters All-Out Attack",
    year: 2001,
    era: "Millennium",
    features: {
      specialEffects: 5,
      story: 4,
      action: 5,
      humor: 1,
      seriousness: 5,
      multipleMonsters: true
    }
  },
  {
    title: "Godzilla Against Mechagodzilla",
    year: 2002,
    era: "Millennium",
    features: {
      specialEffects: 4,
      story: 4,
      action: 4,
      humor: 2,
      seriousness: 4,
      multipleMonsters: true
    }
  },
  {
    title: "Godzilla: Tokyo S.O.S.",
    year: 2003,
    era: "Millennium",
    features: {
      specialEffects: 4,
      story: 3,
      action: 4,
      humor: 2,
      seriousness: 4,
      multipleMonsters: true
    }
  },
  {
    title: "Godzilla: Final Wars",
    year: 2004,
    era: "Millennium",
    features: {
      specialEffects: 4,
      story: 3,
      action: 5,
      humor: 4,
      seriousness: 2,
      multipleMonsters: true
    }
  },
  {
    title: "Godzilla (2014)",
    year: 2014,
    era: "MonsterVerse",
    features: {
      specialEffects: 5,
      story: 3,
      action: 4,
      humor: 1,
      seriousness: 5,
      multipleMonsters: true
    }
  },
  {
    title: "Shin Godzilla",
    year: 2016,
    era: "Reiwa",
    features: {
      specialEffects: 5,
      story: 5,
      action: 3,
      humor: 2,
      seriousness: 5,
      multipleMonsters: false
    }
  },
  {
    title: "Godzilla: King of the Monsters",
    year: 2019,
    era: "MonsterVerse",
    features: {
      specialEffects: 5,
      story: 3,
      action: 5,
      humor: 2,
      seriousness: 4,
      multipleMonsters: true
    }
  },
  {
    title: "Godzilla vs. Kong",
    year: 2021,
    era: "MonsterVerse",
    features: {
      specialEffects: 5,
      story: 3,
      action: 5,
      humor: 3,
      seriousness: 3,
      multipleMonsters: true
    }
  }
];

